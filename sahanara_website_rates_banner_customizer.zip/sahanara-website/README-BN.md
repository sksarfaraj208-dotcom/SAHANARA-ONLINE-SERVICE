# Sahanara Online Service & Telecom — Free Starter

এটি একটি real Supabase Auth + PostgreSQL database starter। Static frontend Vercel-এ host করা যাবে।
এখনই production-এ গ্রাহকের Aadhaar/PAN/ব্যাংক নথি বা অন্য sensitive document upload করবেন না।
এই starter-এ document upload নেই।

## ১) Supabase project তৈরি (মোবাইল Chrome)
1. https://supabase.com খুলে নিজের account তৈরি/login করুন।
2. New project চাপুন। Project name: `sahanara-online`।
3. Database password নিজে সেট করুন এবং নিরাপদে রাখুন; কাউকে দেবেন না।
4. Project তৈরি হলে Project Settings → API (বা API Keys) খুলুন।
5. Project URL এবং `publishable` key (পুরোনো project হলে `anon` key) কপি করুন।
6. `service_role` বা `secret` key কখনো website/browser-এ বসাবেন না।

## ২) Database তৈরি
1. Supabase Dashboard → SQL Editor → New query।
2. `supabase/schema.sql` ফাইলের সম্পূর্ণ SQL কপি করে paste করুন।
3. Run চাপুন। সফল হলে profiles এবং service_requests table তৈরি হবে।

## ৩) Website config
`public/config.js` খুলে এই দুইটি placeholder বদলান:
- `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE`
- `PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE`

শুধু Project URL এবং publishable/anon key ব্যবহার করবেন। Secret/service_role key নয়।

## ৪) Admin account বানানো
1. Website-এ Register করে নিজের admin email দিয়ে account খুলুন।
2. Supabase → Authentication → Users থেকে আপনার user-এর UUID কপি করুন।
3. Supabase → SQL Editor-এ এই query চালান (UUID-র জায়গায় নিজের UUID বসান):

```sql
update public.profiles
set role = 'admin'
where id = 'PASTE-YOUR-USER-UUID-HERE';
```

Admin role শুধু project owner SQL Editor থেকে সেট করবেন। Website থেকে customer নিজের role admin করতে পারবে না।

## ৫) Vercel-এ publish
এই ZIP-এর `public` folder-এর ফাইলগুলো একটি GitHub repository-তে রাখুন। Repository root-এ `public` folder রাখলে Vercel-এর Project Settings → Build and Deployment-এ:
- Framework Preset: Other
- Build Command: ফাঁকা
- Output Directory: `public`
তারপর Deploy করুন। Vercel-এর মোবাইল browser-এ GitHub দিয়ে sign-in করে Import Project করা যায়।
প্রয়োজনে `public`-এর ফাইলগুলো repository root-এ সরিয়ে Output Directory `.` দিন।

## ৬) পরীক্ষা
- Customer email দিয়ে register/login করুন।
- Service Request জমা দিন।
- Logout করে admin account দিয়ে login করুন।
- Admin Dashboard-এ request দেখা এবং status update পরীক্ষা করুন।

## নিরাপত্তা ও সীমাবদ্ধতা
- Supabase email confirmation চালু থাকলে registration-এর পর email confirm করতে হবে।
- Customer শুধু নিজের request দেখতে পারে; admin সব request দেখতে ও status update করতে পারে।
- এই starter-এ customer profile editing, password reset UI, file upload, payment gateway, SMS/WhatsApp automation নেই।
- Public website-এ privacy policy, terms, support process, backups এবং abuse protection যোগ না করে sensitive documents সংগ্রহ করবেন না।
- Aadhaar/PAN full number, OTP, bank PIN/password বা original identity documents এই starter-এ দেবেন না।
- Publishable/anon key frontend-এ থাকা স্বাভাবিক, কিন্তু database security অবশ্যই RLS policies দিয়ে enforce করতে হবে।


## Service-wise Apply Now ও চার্জ
ওয়েবসাইটের হোমপেজে Aadhaar, Voter, PAN, Ration, Driving Licence, Vehicle RC, Ayushman, PVC Printing, Online Form, Recharge, Banking/Bill Payment এবং Print/Scan-এর আলাদা Service Card ও Apply Now বাটন আছে। বাটনে চাপলে সংশ্লিষ্ট সার্ভিস আবেদন ফর্মে নির্বাচন হবে। প্রতিটি কার্ডে আপাতত “চার্জ জানতে দোকানে যোগাযোগ করুন” লেখা আছে, কারণ প্রকৃত চার্জ দোকান থেকে নির্ধারণ করতে হবে।

**গোপনীয়তা:** এই সংস্করণে Aadhaar/PAN নম্বর, OTP, পাসওয়ার্ড বা পরিচয়পত্রের ছবি ফর্মে দেবেন না। নিরাপদ document-upload ব্যবস্থা আলাদাভাবে তৈরি ও পরীক্ষা না করা পর্যন্ত সংবেদনশীল নথি সংগ্রহ করবেন না।

## ৭) নতুন সুবিধা: Rate ও Banner Customize
- Updated `supabase/schema.sql` চালালে `service_catalog` এবং `site_settings` table তৈরি হবে। আগে পুরোনো SQL চালিয়ে থাকলেও এই updated SQL পুরোটা আবার চালাতে পারবেন; এটি পুরোনো customer/request table মুছে দেয় না।
- Admin account দিয়ে login করলে Admin Dashboard-এর নিচে **Service Rate Management** দেখা যাবে। প্রতিটি পরিষেবার Rate (₹) লিখে Save Rate চাপুন। Rate ফাঁকা রাখলে public website-এ যোগাযোগের বার্তা দেখাবে।
- **Customize Website Banner** থেকে ছোট heading, main title, subtitle, offer/announcement এবং banner background color বদলে Save Banner Design চাপুন। পরিবর্তন public homepage-এ দেখা যাবে।
- এই সংস্করণে banner-এর লেখা ও রং customize করা যায়; নিজের ছবি ফাইল upload করে banner বানানোর সুবিধা এখনো নেই।
- Rate শুধু আপনার দোকানের service charge হিসেবে দিন। সরকারি ফি বা তৃতীয় পক্ষের চার্জ থাকলে আলাদা করে স্পষ্টভাবে জানাবেন।
