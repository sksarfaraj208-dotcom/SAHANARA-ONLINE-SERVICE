// Supabase project settings: replace both values with your own project values.
// Use the Supabase publishable key (or legacy anon key), NEVER the service_role/secret key.
window.SAHANARA_SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
window.SAHANARA_SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE";
