(() => {
  const $ = id => document.getElementById(id);
  const url = window.SAHANARA_SUPABASE_URL;
  const key = window.SAHANARA_SUPABASE_ANON_KEY;
  let supabase = null, mode = "login", currentUser = null, currentRole = "customer";
  const defaults = [
    ["Aadhaar Card Assistance","আধার সংক্রান্ত অনলাইন সহায়তা ও উপলব্ধ পরিষেবা।","🪪"],
    ["Voter Card","ভোটার কার্ড সংক্রান্ত আবেদন ও অনলাইন সহায়তা।","🗳️"],
    ["PAN Card Assistance","PAN কার্ড সংক্রান্ত আবেদন ও সহায়তা।","🧾"],
    ["Ration Card","রেশন কার্ড সংক্রান্ত অনলাইন ফর্ম ও সহায়তা।","🍚"],
    ["Driving Licence","ড্রাইভিং লাইসেন্স সংক্রান্ত অনলাইন সহায়তা।","🚗"],
    ["Vehicle RC","গাড়ির RC সংক্রান্ত অনলাইন সহায়তা।","🚘"],
    ["Ayushman Card","Ayushman কার্ড সংক্রান্ত উপলব্ধ পরিষেবা।","💳"],
    ["PVC Card Printing","Aadhaar, Voter, PAN, Ration ও অন্যান্য PVC কার্ড প্রিন্টিং।","🖨️"],
    ["Online Form Fill-Up","বিভিন্ন অনলাইন ফর্ম পূরণে সহায়তা।","📝"],
    ["Mobile & DTH Recharge","মোবাইল ও DTH রিচার্জ পরিষেবা।","📱"],
    ["Banking & Bill Payment Assistance","ব্যাংকিং সহায়তা ও বিভিন্ন বিল পেমেন্ট।","🏦"],
    ["Print & Scan","ডকুমেন্ট প্রিন্ট ও স্ক্যান পরিষেবা।","📄"],
    ["Other Online Service","অন্যান্য অনলাইন পরিষেবা।","📋"]
  ].map(([service,description,icon]) => ({service,description,icon,price:null,price_note:"চার্জ জানতে দোকানে যোগাযোগ করুন"}));
  let services = defaults;
  const configured = url && key && !url.includes("PASTE_") && !key.includes("PASTE_");

  function message(id, text, error=false) {
    $(id).textContent = text;
    $(id).style.color = error ? "#b42318" : "#17613b";
  }
  function safe(s) {
    return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function renderServices() {
    $("servicesGrid").innerHTML = services.map(s => {
      const priceText = s.price !== null && s.price !== "" && Number.isFinite(Number(s.price))
        ? `চার্জ: ₹${Number(s.price).toFixed(Number(s.price)%1 ? 2 : 0)}`
        : (s.price_note || "চার্জ জানতে দোকানে যোগাযোগ করুন");
      return `<article class="service-card"><div class="service-icon">${safe(s.icon || "📄")}</div><h3>${safe(s.service)}</h3><p>${safe(s.description)}</p><small>${safe(priceText)}</small><button class="primary apply-service" data-service="${safe(s.service)}">Apply Now</button></article>`;
    }).join("");
    document.querySelectorAll(".apply-service").forEach(button => button.addEventListener("click", () => {
      if ($("service")) $("service").value = button.dataset.service;
      const target = currentUser ? $("requestForm") : $("authSection");
      target.scrollIntoView({behavior:"smooth",block:"start"});
      if (!currentUser && configured) message("authMessage", "আবেদন করতে আগে Login অথবা Register করুন।");
    }));
  }
  function applyBanner(data) {
    if (!data) return;
    $("bannerEyebrow").textContent = data.banner_eyebrow || "WELCOME TO SAHANARA";
    $("bannerTitle").textContent = data.banner_title || "আপনার অনলাইন পরিষেবা, এখন আরও সহজ";
    $("bannerSubtitle").textContent = data.banner_subtitle || "";
    const announcement = $("bannerAnnouncement");
    announcement.textContent = data.banner_announcement || "";
    announcement.classList.toggle("hidden", !data.banner_announcement);
    if (/^#[0-9a-fA-F]{6}$/.test(data.banner_color || "")) $("bannerSection")?.style.setProperty("--banner-color", data.banner_color);
  }
  async function loadPublicContent() {
    const [serviceResult, settingsResult] = await Promise.all([
      supabase.from("service_catalog").select("service,description,icon,price,price_note").order("service"),
      supabase.from("site_settings").select("banner_eyebrow,banner_title,banner_subtitle,banner_announcement,banner_color").eq("id",1).maybeSingle()
    ]);
    if (!serviceResult.error && serviceResult.data?.length) services = serviceResult.data;
    renderServices();
    if (!settingsResult.error && settingsResult.data) applyBanner(settingsResult.data);
  }
  renderServices();
  applyBanner({banner_eyebrow:"WELCOME TO SAHANARA",banner_title:"আপনার অনলাইন পরিষেবা, এখন আরও সহজ",banner_subtitle:"অনলাইন ফর্ম, PVC কার্ড প্রিন্টিং এবং বিভিন্ন ডিজিটাল পরিষেবার জন্য আবেদন করুন।",banner_announcement:"",banner_color:"#e9f2ff"});

  if (!configured || !window.supabase?.createClient) {
    $("setupWarning").classList.remove("hidden");
    $("authMessage").textContent = "Supabase configuration যোগ করার পর Login/Register চালু হবে।";
    $("authSubmit").disabled = true;
    return;
  }
  supabase = window.supabase.createClient(url, key);
  loadPublicContent().catch(err => console.warn("Public content could not load", err));

  function setMode(next) {
    mode = next;
    $("loginTab").classList.toggle("active", mode === "login");
    $("registerTab").classList.toggle("active", mode === "register");
    $("nameLabel").classList.toggle("hidden", mode !== "register");
    $("fullName").required = mode === "register";
    $("authSubmit").textContent = mode === "login" ? "Login" : "Create Account";
    $("authMessage").textContent = "";
  }
  $("loginTab").onclick = () => setMode("login");
  $("registerTab").onclick = () => setMode("register");

  $("authForm").onsubmit = async e => {
    e.preventDefault(); $("authSubmit").disabled = true; message("authMessage", "Please wait…");
    const email = $("email").value.trim(), password = $("password").value;
    try {
      if (mode === "register") {
        const full_name = $("fullName").value.trim();
        const {data,error} = await supabase.auth.signUp({email,password,options:{data:{full_name}}});
        if (error) throw error;
        message("authMessage", data.session ? "Account তৈরি হয়েছে।" : "Registration হয়েছে। Email confirmation থাকলে Inbox দেখে account confirm করুন।");
      } else {
        const {error} = await supabase.auth.signInWithPassword({email,password}); if (error) throw error;
      }
    } catch(err) { message("authMessage",err.message || "কাজটি সম্পন্ন হয়নি।",true); }
    finally { $("authSubmit").disabled = false; }
  };
  $("logoutBtn").onclick = async () => { await supabase.auth.signOut(); };
  $("requestForm").onsubmit = async e => {
    e.preventDefault(); const btn=e.submitter; btn.disabled=true;
    try {
      const {error}=await supabase.from("service_requests").insert({user_id:currentUser.id,customer_name:currentUser.user_metadata?.full_name || currentUser.email,phone:$("phone").value.trim(),service:$("service").value,details:$("details").value.trim()});
      if(error) throw error; e.target.reset(); message("requestMessage","আবেদন জমা হয়েছে। নিচে আপনার Request ID দেখতে পাবেন।"); await loadRequests();
    } catch(err) { message("requestMessage",err.message || "আবেদন জমা হয়নি।",true); }
    finally { btn.disabled=false; }
  };

  async function getRole() {
    const {data,error}=await supabase.from("profiles").select("role").eq("id",currentUser.id).maybeSingle();
    if(error) throw error; currentRole=data?.role === "admin" ? "admin" : "customer";
    $("roleLabel").textContent=currentRole === "admin" ? "Administrator" : "Customer Account";
    $("adminSection").classList.toggle("hidden",currentRole !== "admin");
    if(currentRole === "admin") { await loadRateEditor(); await loadBannerEditor(); }
  }
  function requestCard(r,admin=false) {
    return `<article class="request"><div class="request-top"><b>${safe(r.service)}</b><span class="status">${safe(r.status)}</span></div><p><b>Request ID:</b> ${safe(r.id)}<br><b>Customer:</b> ${safe(r.customer_name)}${admin?`<br><b>Phone:</b> ${safe(r.phone)}`:""}<br><b>Submitted:</b> ${new Date(r.created_at).toLocaleString()}</p><p>${safe(r.details || "No extra details")}</p>${admin?`<label>Update Status<select data-request-id="${safe(r.id)}" class="statusSelect">${["Pending","Processing","Completed","Rejected"].map(s=>`<option ${s===r.status?"selected":""}>${s}</option>`).join("")}</select></label>`:""}</article>`;
  }
  async function loadRequests() {
    const {data,error}=await supabase.from("service_requests").select("*").order("created_at",{ascending:false}); if(error) throw error;
    const mine=(data||[]).filter(r=>r.user_id===currentUser.id);
    $("myRequests").innerHTML=mine.length?mine.map(r=>requestCard(r)).join(''):'<p class="muted">এখনও কোনও আবেদন করেননি।</p>';
    if(currentRole === "admin") {
      $("allRequests").innerHTML=data?.length?data.map(r=>requestCard(r,true)).join(''):'<p class="muted">কোনও আবেদন নেই।</p>';
      document.querySelectorAll(".statusSelect").forEach(sel=>sel.onchange=async()=>{sel.disabled=true;const {error}=await supabase.from("service_requests").update({status:sel.value}).eq("id",sel.dataset.requestId);sel.disabled=false;if(error){alert("Status update হয়নি: "+error.message);return;}await loadRequests();});
    }
  }
  async function loadRateEditor() {
    const {data,error}=await supabase.from("service_catalog").select("service,price,price_note").order("service");
    if(error) { $("rateEditor").textContent="Rate list load হয়নি: "+error.message; return; }
    $("rateEditor").innerHTML=(data||[]).map((s,i)=>`<form class="rate-row" data-service="${safe(s.service)}"><b>${safe(s.service)}</b><label>Rate (₹)<input class="rate-value" type="number" min="0" step="0.01" value="${s.price===null?"":safe(s.price)}" placeholder="যেমন ৫০"></label><label>Rate না থাকলে দেখাবে<input class="rate-note" maxlength="100" value="${safe(s.price_note||"চার্জ জানতে দোকানে যোগাযোগ করুন")}"></label><button class="primary" type="submit">Save Rate</button></form>`).join("");
    document.querySelectorAll(".rate-row").forEach(form=>form.onsubmit=async e=>{
      e.preventDefault(); const btn=form.querySelector("button"); btn.disabled=true;
      const raw=form.querySelector(".rate-value").value.trim(); const price=raw===""?null:Number(raw);
      if(price!==null && (!Number.isFinite(price)||price<0)){message("rateMessage","সঠিক rate লিখুন।",true);btn.disabled=false;return;}
      const {error}=await supabase.from("service_catalog").update({price,price_note:form.querySelector(".rate-note").value.trim()||"চার্জ জানতে দোকানে যোগাযোগ করুন",updated_at:new Date().toISOString()}).eq("service",form.dataset.service);
      btn.disabled=false;
      if(error){message("rateMessage","Rate save হয়নি: "+error.message,true);return;}
      message("rateMessage","Rate সফলভাবে আপডেট হয়েছে।"); await loadPublicContent(); await loadRateEditor();
    });
  }
  async function loadBannerEditor() {
    const {data,error}=await supabase.from("site_settings").select("*").eq("id",1).maybeSingle(); if(error||!data)return;
    $("editBannerEyebrow").value=data.banner_eyebrow||""; $("editBannerTitle").value=data.banner_title||"";
    $("editBannerSubtitle").value=data.banner_subtitle||""; $("editBannerAnnouncement").value=data.banner_announcement||"";
    $("editBannerColor").value=/^#[0-9a-fA-F]{6}$/.test(data.banner_color||"")?data.banner_color:"#e9f2ff";
  }
  $("bannerForm").onsubmit=async e=>{
    e.preventDefault(); const btn=e.submitter;btn.disabled=true;
    const payload={banner_eyebrow:$("editBannerEyebrow").value.trim(),banner_title:$("editBannerTitle").value.trim(),banner_subtitle:$("editBannerSubtitle").value.trim(),banner_announcement:$("editBannerAnnouncement").value.trim(),banner_color:$("editBannerColor").value,updated_at:new Date().toISOString()};
    const {error}=await supabase.from("site_settings").update(payload).eq("id",1);btn.disabled=false;
    if(error){message("bannerMessage","Banner save হয়নি: "+error.message,true);return;}
    applyBanner(payload);message("bannerMessage","Banner সফলভাবে customize হয়েছে।");
  };
  async function showSession(session) {
    currentUser=session?.user||null; $("authSection").classList.toggle("hidden",!!currentUser); $("appSection").classList.toggle("hidden",!currentUser); $("logoutBtn").classList.toggle("hidden",!currentUser);
    if(!currentUser)return; $("welcomeName").textContent=currentUser.user_metadata?.full_name||currentUser.email;
    try{await getRole();await loadRequests();}catch(err){console.error(err);alert("Account data load করতে সমস্যা হয়েছে। Database setup এবং RLS policy পরীক্ষা করুন।");}
  }
  supabase.auth.onAuthStateChange((_event,session)=>{setTimeout(()=>showSession(session),0);});
  supabase.auth.getSession().then(({data})=>showSession(data.session));
})();
